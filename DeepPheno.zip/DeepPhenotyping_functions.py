from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import bokeh.plotting as bp
from bokeh.models import HoverTool, BoxSelectTool
from bokeh.plotting import figure, show, output_notebook
from bokeh.transform import factor_cmap
from bokeh.models import  CategoricalColorMapper
import pandas as pd
from sklearn.cluster import KMeans

def makeTSNE_Cluster(values, l_id, l_lbl, title, clusters, pal, seed=1234):
    
    plot_tfidf = bp.figure(plot_width=700, plot_height=600, title="A phenoMap of %s patients" % (title),
        tools="pan,wheel_zoom,box_zoom,reset,hover,save",
        x_axis_type=None, y_axis_type=None, min_border=1)
    
    
    #plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=300, c='red')

    # dimensionality reduction. converting the vectors to 2d vectors
    tsne_model = TSNE(n_components=2, verbose=1, random_state=seed)
    tsne_2d = tsne_model.fit_transform(values)
    
    kmeans = KMeans(n_clusters=clusters, init='k-means++', max_iter=300, n_init=10, random_state=0)
    pred_y = kmeans.fit_predict(tsne_2d)
    print(kmeans)

    color_mapper = CategoricalColorMapper(factors=list(set(l_lbl)), palette=pal)

    # putting everything in a dataframe
    tsne_df = pd.DataFrame(tsne_2d, columns=['x', 'y'])
    tsne_df['pt'] = l_id
    tsne_df['label'] = l_lbl #df.cc.astype('category').cat.codes
    
    tsne_df2 = pd.DataFrame({'x' : kmeans.cluster_centers_[:, 0], 'y': kmeans.cluster_centers_[:, 1]})
    tsne_df2['pt'] = ["Cluster center %i" % (i) for i in range(len(kmeans.cluster_centers_))]
    #tsne_df['pt'] = l_id
    #tsne_df2['label'] = pred_y
                         

    #mapper = factor_cmap('cat', palette=Spectral6[:4], factors=tsne_df['cat'])
    # plotting. the corresponding word appears when you hover on the data point.
    plot_tfidf.scatter(x='x', y='y', source=tsne_df, legend_field="label", size=10,  color={'field': 'label', 'transform': color_mapper}) # fill_color=mapper
    plot_tfidf.scatter(x='x', y='y', source=tsne_df2, size=15,  marker="diamond", color='grey') # fill_color=mapper
    hover = plot_tfidf.select(dict(type=HoverTool))
    hover.tooltips={"pt": "@pt"}
    bp.output_file('TSNE/Kmeans_phenoMap_tsne_%s.html' % (title), mode='inline')
    bp.save(plot_tfidf)
    print('\nTSNE figure saved under location: TSNE/Kmeans_phenoMap_tsne_%s.html' % (title))
    return 


def makeTSNE(values, l_id, l_lbl, title, pal, seed=1234):
    plot_tfidf = bp.figure(plot_width=700, plot_height=600, title="A phenoMap of %s patients" % (title),
        tools="pan,wheel_zoom,box_zoom,reset,hover,save",
        x_axis_type=None, y_axis_type=None, min_border=1)

    # dimensionality reduction. converting the vectors to 2d vectors
    tsne_model = TSNE(n_components=2, verbose=1, random_state=seed)
    tsne_2d = tsne_model.fit_transform(values)

    color_mapper = CategoricalColorMapper(factors=list(set(l_lbl)), palette=pal)

    # putting everything in a dataframe
    tsne_df = pd.DataFrame(tsne_2d, columns=['x', 'y'])
    tsne_df['pt'] = l_id
    tsne_df['label'] = l_lbl #df.cc.astype('category').cat.codes

    #mapper = factor_cmap('cat', palette=Spectral6[:4], factors=tsne_df['cat'])
    # plotting. the corresponding word appears when you hover on the data point.
    plot_tfidf.scatter(x='x', y='y', source=tsne_df, legend_field="label", radius=0.5,  color={'field': 'label', 'transform': color_mapper}) # fill_color=mapper
    hover = plot_tfidf.select(dict(type=HoverTool))
    hover.tooltips={"pt": "@pt"}
    bp.output_file('TSNE/phenoMap_tsne_%s.html' % (title), mode='inline')
    bp.save(plot_tfidf)
    print('\nTSNE figure saved under location: TSNE/phenoMap_tsne_%s.html' % (title))
    return 

def makePCA(values, l_id, l_lbl, title, pal, seed=1234):
    plot_tfidf = bp.figure(plot_width=700, plot_height=600, title="A phenoMap of %s patients" % (title),
        tools="pan,wheel_zoom,box_zoom,reset,hover,save",
        x_axis_type=None, y_axis_type=None, min_border=1)

    # dimensionality reduction. converting the vectors to 2d vectors
    pca_model = PCA(n_components=2, random_state=seed) # , verbose=1, random_state=0
    pca_2d = pca_model.fit_transform(values)
    print('Explained PCA:\tPC1=', pca_model.explained_variance_ratio_[0], '\tPC2=',pca_model.explained_variance_ratio_[1])
    color_mapper = CategoricalColorMapper(factors=list(set(l_lbl)), palette=pal)

    # putting everything in a dataframe
    pca_df = pd.DataFrame(pca_2d, columns=['x', 'y'])
    pca_df['pt'] = l_id
    pca_df['label'] = l_lbl #df.cc.astype('category').cat.codes
    
    # plotting. the corresponding word appears when you hover on the data point.
    plot_tfidf.scatter(x='x', y='y', source=pca_df, legend_field="label", radius=0.05,  color={'field': 'label', 'transform': color_mapper}) # fill_color=mapper
    hover = plot_tfidf.select(dict(type=HoverTool))
    hover.tooltips={"pt": "@pt"}
    bp.output_file('PCA/phenoMap_pca_%s.html' % (title), mode='inline')
    bp.save(plot_tfidf)
    print('PCA figure saved under location: PCA/phenoMap_pca_%s.html' % (title))
    return